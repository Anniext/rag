# 使用示例

本目录包含 RAG MySQL 查询系统的各种使用示例，涵盖不同场景和用例。

## 示例分类

### 基础使用

- [基本查询示例](basic-usage.md) - 简单的查询操作
- [连接和认证](connection-auth.md) - 连接建立和用户认证
- [会话管理](session-management.md) - 会话创建和管理

### 查询场景

- [简单查询](queries/simple-queries.md) - 基础的数据查询
- [复杂查询](queries/complex-queries.md) - 多表关联和聚合查询
- [统计分析查询](queries/analytics.md) - 数据统计和分析

### 客户端集成

- [JavaScript 客户端](clients/javascript.md) - Web 前端集成
- [Python 客户端](clients/python.md) - Python 应用集成
- [Go 客户端](clients/go.md) - Go 应用集成

### 高级功能

- [Schema 管理](advanced/schema-management.md) - 数据库结构管理
- [缓存优化](advanced/caching.md) - 缓存策略和优化
- [性能调优](advanced/performance.md) - 性能优化技巧
- [错误处理](advanced/error-handling.md) - 错误处理最佳实践

### 部署和配置

- [配置管理](deployment/configuration.md) - 配置文件管理和部署最佳实践

## 快速开始

如果你是第一次使用，建议按以下顺序阅读：

1. [基本查询示例](basic-usage.md) - 了解基本用法
2. [简单查询](queries/simple-queries.md) - 掌握查询技巧
3. [客户端集成](clients/) - 选择适合的客户端语言
4. [配置和部署](deployment/configuration.md) - 了解部署最佳实践

## 示例数据

所有示例都基于以下示例数据库结构：

### 用户表 (users)

```sql
CREATE TABLE users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL COMMENT '用户姓名',
    email VARCHAR(255) UNIQUE NOT NULL COMMENT '邮箱地址',
    phone VARCHAR(20) COMMENT '手机号码',
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### 订单表 (orders)

```sql
CREATE TABLE orders (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL,
    order_no VARCHAR(50) UNIQUE NOT NULL COMMENT '订单号',
    amount DECIMAL(10,2) NOT NULL COMMENT '订单金额',
    status ENUM('pending', 'paid', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

### 产品表 (products)

```sql
CREATE TABLE products (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL COMMENT '产品名称',
    description TEXT COMMENT '产品描述',
    price DECIMAL(10,2) NOT NULL COMMENT '产品价格',
    category_id BIGINT,
    stock_quantity INT DEFAULT 0 COMMENT '库存数量',
    status ENUM('active', 'inactive', 'discontinued') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### 订单详情表 (order_items)

```sql
CREATE TABLE order_items (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_id BIGINT NOT NULL,
    product_id BIGINT NOT NULL,
    quantity INT NOT NULL COMMENT '购买数量',
    unit_price DECIMAL(10,2) NOT NULL COMMENT '单价',
    total_price DECIMAL(10,2) NOT NULL COMMENT '小计',
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);
```

### 分类表 (categories)

```sql
CREATE TABLE categories (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL COMMENT '分类名称',
    parent_id BIGINT COMMENT '父分类ID',
    description TEXT COMMENT '分类描述',
    sort_order INT DEFAULT 0 COMMENT '排序',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES categories(id)
);
```

## 环境要求

运行示例需要以下环境：

- RAG MySQL 查询系统服务端
- MySQL 数据库 (5.7+ 或 8.0+)
- Redis 缓存服务 (可选)
- 支持 WebSocket 的客户端环境

## 配置说明

示例中使用的默认配置：

```yaml
# 服务器配置
server:
  host: localhost
  port: 8080

# 数据库配置
database:
  host: localhost
  port: 3306
  username: rag_user
  password: rag_password
  database: rag_demo

# 认证配置
auth:
  jwt_secret: demo_secret_key
  token_expiry: 24h
```

## 注意事项

1. **安全提醒**: 示例中的密钥和密码仅用于演示，生产环境请使用安全的配置
2. **数据隔离**: 建议在独立的测试数据库中运行示例
3. **版本兼容**: 示例基于最新版本，旧版本可能存在差异
4. **性能考虑**: 示例重点展示功能，生产环境需要额外的性能优化

## 贡献指南

欢迎贡献新的示例：

1. 创建新的示例文件
2. 添加详细的说明和注释
3. 确保示例可以正常运行
4. 更新相关的索引文件
5. 提交 Pull Request

## 获取帮助

如果在使用示例时遇到问题：

1. 查看 [API 文档](../api/)
2. 检查 [错误码参考](../api/error-codes.md)
3. 查看 [故障排查指南](../development/troubleshooting.md)
4. 在 GitHub 上提交 Issue

## 许可证

所有示例代码采用 MIT 许可证，可以自由使用和修改。
